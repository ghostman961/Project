import sys
import sqlite3

from PyQt5 import QtGui
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit, QListWidget, QComboBox, \
    QTableWidget, QListWidgetItem, QMainWindow, QTableWidgetItem


class Start_window(QWidget):
    def __init__(self, png_name='start_bg.png'):
        super().__init__()
        self.png_name1 = png_name

        self.setWindowTitle("Кинотеатр")
        self.setGeometry(0, 0, 831, 581)
        self.setFixedSize(831, 581)

        self.lbl = QLabel(self)
        self.pix = QtGui.QPixmap(png_name)
        self.lbl.setPixmap(self.pix)
        self.lbl.move(0, 0)

        self.text_lbl = QLabel('<h1 style="color: rgb(200, 55, 55);">ⓀⒾⓃⓄⒼⓄ</h1>',
                               self)
        self.text_lbl.setFont(QFont('Gothic', 40))
        self.text_lbl.move(100, 10)
        self.text_lbl.resize(700, 150)

        self.btn1 = QPushButton('Искать Фильм', self)
        self.btn1.setFont(QFont('Arial', 23))
        self.btn1.move(250, 340)
        self.btn1.resize(350, 65)
        self.btn1.clicked.connect(self.open_search_film)

        self.btn2 = QPushButton("Рассписание", self)
        self.btn2.setFont(QFont('Arial', 23))
        self.btn2.move(250, 410)
        self.btn2.resize(350, 65)
        self.btn2.clicked.connect(self.open_schedule)

        self.btn3 = QPushButton("Настройки", self)
        self.btn3.setFont(QFont('Arial', 23))
        self.btn3.move(250, 480)
        self.btn3.resize(350, 65)
        self.btn3.clicked.connect(self.open_settings)

    def open_search_film(self):
        self.close()
        self.search_film = Search_film(self.png_name1)
        self.search_film.show()

    def open_schedule(self):
        self.close()
        self.schedule = Schedule(self.png_name1)
        self.schedule.show()

    def open_settings(self):
        self.close()
        self.settings = Settings(self.png_name1)
        self.settings.show()


class Search_film(QWidget):
    def __init__(self, png_name='start_bg.png'):
        super().__init__()
        self.png_name1 = png_name
        self.con = sqlite3.connect("cinema_films.db")
        self.params = {"Жанр": "genre", "Название": "title"}

        self.setWindowTitle("Поиск фильма")
        self.setGeometry(0, 0, 831, 581)
        self.setFixedSize(831, 581)

        self.lbl = QLabel(self)
        self.pix = QtGui.QPixmap(self.png_name1)
        self.lbl.setPixmap(self.pix)
        self.lbl.move(0, 0)

        self.btn1 = QPushButton('<--', self)
        self.btn1.move(5, 5)
        self.btn1.resize(40, 30)
        self.btn1.clicked.connect(self.open_start_window)
        self.btn1.setStyleSheet('QPushButton {background-color: black; color: red;}')
        self.btn1.setFont(QFont('Gothic', 20))

        self.Title = QLineEdit(self)
        self.Title.move(440, 60)
        self.Title.resize(250, 25)

        self.searchButton = QPushButton('Искать', self)
        self.searchButton.move(690, 59)
        self.searchButton.resize(70, 27)
        self.searchButton.setFont(QFont('Gothic', 11))
        self.searchButton.clicked.connect(self.search)

        self.listWidget = QListWidget(self)
        self.listWidget.move(440, 95)
        self.listWidget.resize(320, 400)

        self.comboBox = QComboBox(self)
        self.comboBox.move(60, 60)
        self.comboBox.resize(350, 25)
        self.comboBox.addItem('Жанр')
        self.comboBox.addItem("Название")

        self.tab8 = QTableWidget(self)
        self.tab8.setColumnCount(4)
        self.tab8.setRowCount(1)
        self.tab8.setMaximumWidth(530)
        self.tab8.move(10, 135)
        self.tab8.setFixedSize(420, 50)
        self.tab8.setHorizontalHeaderLabels(["Название", "Год", "Жанр", 'День'])

        self.btn2 = QPushButton('Добавить', self)
        self.btn2.move(10, 185)
        self.btn2.resize(420, 35)
        self.btn2.setFont(QFont('Gothic', 11))
        self.btn2.clicked.connect(self.get_data)

        self.tab9 = QTableWidget(self)
        self.tab9.setColumnCount(4)
        self.tab9.setRowCount(1)
        self.tab9.setMaximumWidth(530)
        self.tab9.move(10, 335)
        self.tab9.setFixedSize(420, 50)
        self.tab9.setHorizontalHeaderLabels(["Название", "Год", "Жанр", 'День'])

        self.btn3 = QPushButton('Выбрать для редактирования', self)
        self.btn3.move(10, 385)
        self.btn3.resize(420, 35)
        self.btn3.setFont(QFont('Gothic', 11))
        self.btn3.clicked.connect(self.select_red_obj)

        self.btn4 = QPushButton('Изменить', self)
        self.btn4.move(10, 420)
        self.btn4.resize(420, 35)
        self.btn4.setFont(QFont('Gothic', 11))
        self.btn4.clicked.connect(self.redaction_obj)
        self.btn4.setVisible(False)

    def select_red_obj(self):
        global rt1, rt2, rt3, rt4
        if self.tab9.item(0, 0) and self.tab9.item(0, 1) and self.tab9.item(0, 2) and self.tab9.item(0, 3):
            self.btn4.setVisible(True)
            rt1 = self.tab9.item(0, 0).text()
            rt2 = int(self.tab9.item(0, 1).text())
            rt3 = self.tab9.item(0, 2).text()
            rt4 = self.tab9.item(0, 3).text()
        else:
            self.first_eror = First_error()
            self.first_eror.show()

    def redaction_obj(self):
        if self.tab9.item(0, 0) and self.tab9.item(0, 1) and self.tab9.item(0, 2) and self.tab9.item(0, 3):
            with self.con:
                cur = self.con.cursor()
                r1 = self.tab9.item(0, 0).text()
                r2 = self.tab9.item(0, 1).text()
                r3 = self.tab9.item(0, 2).text()
                r4 = self.tab9.item(0, 3).text()
                cur.execute(
                    """UPDATE films SET title = '%s', year = '%s', genre = '%s', day = '%s' WHERE  title = '%s' AND 
                    year = '%s' AND genre = '%s' AND day = '%s'""" % (
                        r1, r2, r3, r4, rt1, rt2, rt3, rt4))
            self.con.commit()
            self.btn4.setVisible(False)
        else:
            self.first_eror = First_error()
            self.first_eror.show()

    def get_data(self):
        if self.tab8.item(0, 0) and self.tab8.item(0, 1) and self.tab8.item(0, 2) and self.tab8.item(0, 3):
            title_d = self.tab8.item(0, 0).text()
            year_d = self.tab8.item(0, 1).text()
            genre_d = self.tab8.item(0, 2).text()
            day_d = self.tab8.item(0, 3).text()
            image_d = 'noname.png'

            cur = self.con.cursor()
            cur.execute(f"INSERT INTO films VALUES (?, ?, ?, ?, ?)", (title_d, genre_d, int(year_d), image_d, day_d))
            self.con.commit()
        else:
            self.first_eror = First_error()
            self.first_eror.show()

    def search(self):
        self.listWidget.clear()
        el = self.comboBox.currentText()
        if self.params.get(el) == "title":
            req = "SELECT genre,title FROM films WHERE title LIKE '%{}%'".format(self.Title.text())
        else:
            req = "SELECT genre,title FROM films WHERE genre LIKE '%{}%'".format(self.Title.text())
        cur = self.con.cursor()
        data = cur.execute(req).fetchall()
        elems = [[QPushButton(i[1], self), i[1]] for i in data]
        for btn, loc_id in elems:
            btn.clicked.connect(self.show_info(loc_id))

        items = [QListWidgetItem() for _ in elems]
        for i in range(len(items)):
            self.listWidget.addItem(items[i])
            items[i].setSizeHint(elems[i][0].sizeHint())
            self.listWidget.setItemWidget(items[i], elems[i][0])

    def show_info(self, loc_id):
        def call_info():
            cur = self.con.cursor()
            title, genre, year, image, day = cur.execute(
                f"SELECT title,genre,year,image,day From films Where title = '{loc_id}'").fetchone()
            if image:
                info_book = Film_widget(self, title, genre, str(year), image, day)
            else:
                info_book = Film_widget(self, title, genre, str(year), day)
            info_book.show()

        return call_info

    def open_start_window(self):
        self.close()
        self.start_window = Start_window(self.png_name1)
        self.start_window.show()


class Film_widget(QMainWindow):
    def __init__(self, parent=None, title=None, genre=None, year=None, image='noname.png', day=None):
        super().__init__(parent)
        self.con = sqlite3.connect('cinema_films.db')
        self.setWindowTitle('Инфромация о фильме')
        self.setGeometry(0, 0, 345, 446)
        self.setFixedSize(345, 446)

        self.label = QLabel(self)
        self.label.setGeometry(90, 20, 161, 181)

        self.label_2 = QLabel('Название', self)
        self.label_2.setFont(QFont('MS Shell Dlg 2', 18))
        self.label_2.setGeometry(35, 220, 280, 30)

        self.label_3 = QLabel(self)
        self.label_3.setGeometry(35, 250, 280, 15)

        self.label_4 = QLabel('Жанр', self)
        self.label_4.setFont(QFont('MS Shell Dlg 2', 18))
        self.label_4.setGeometry(35, 265, 280, 30)

        self.label_5 = QLabel(self)
        self.label_5.setGeometry(35, 295, 280, 15)

        self.label_6 = QLabel('Год выпуска', self)
        self.label_6.setFont(QFont('MS Shell Dlg 2', 18))
        self.label_6.setGeometry(35, 310, 280, 30)

        self.label_7 = QLabel(self)
        self.label_7.setGeometry(35, 340, 280, 15)

        self.label_8 = QLabel('День показа', self)
        self.label_8.setFont(QFont('MS Shell Dlg 2', 18))
        self.label_8.setGeometry(35, 355, 280, 30)

        self.label_9 = QLabel(self)
        self.label_9.setGeometry(35, 385, 280, 15)

        self.btn10 = QPushButton('Удалить', self)
        self.btn10.setGeometry(35, 400, 280, 20)
        self.btn10.clicked.connect(self.delete)

        self.label_3.setText(title)
        self.label_5.setText(genre)
        self.label_7.setText(year)
        self.label_9.setText(day)

        self.title = title
        self.genre = genre
        self.year = year
        self.day = day

        self.pixmap = QPixmap(image)
        self.label.setPixmap(self.pixmap)

    def delete(self):
        with self.con:
            cur = self.con.cursor()
            cur.execute(
                """DELETE FROM films WHERE title = '%s' AND genre = '%s' AND year = '%s' AND day = '%s'""" % (
                    self.title, self.genre, self.year, self.day))


class Schedule(QWidget):
    def __init__(self, png_name='start_bg.png'):
        super().__init__()
        self.png_name1 = png_name

        self.setWindowTitle("Расписание")
        self.setGeometry(0, 0, 831, 831)
        self.setFixedSize(831, 831)

        if png_name == 'start_bg.png':
            self.png_name2 = 'start_bg_s.png'
        elif png_name == 'start_bg2.png':
            self.png_name2 = 'start_bg_s2.png'
        elif png_name == 'start_bg3.png':
            self.png_name2 = 'start_bg_s3.png'
        elif png_name == 'start_bg4.png':
            self.png_name2 = 'start_bg_s4.png'

        self.lbl = QLabel(self)
        self.pix = QtGui.QPixmap(self.png_name2)
        self.lbl.setPixmap(self.pix)
        self.lbl.move(0, 0)

        self.btn1 = QPushButton('<--', self)
        self.btn1.move(5, 5)
        self.btn1.resize(40, 30)
        self.btn1.clicked.connect(self.open_start_window)
        self.btn1.setStyleSheet('QPushButton {background-color: black; color: red;}')
        self.btn1.setFont(QFont('Gothic', 20))

        self.tab1 = QTableWidget(self)
        self.tab1.setColumnCount(1)
        self.tab1.setRowCount(5)
        self.tab1.setMaximumWidth(300)
        self.tab1.move(30, 75)
        self.tab1.setFixedSize(317, 130)
        self.tab1.verticalHeader().setDefaultSectionSize(20)
        self.tab1.horizontalHeader().setDefaultSectionSize(317)
        self.tab1.setHorizontalHeaderLabels(["Навание"])

        self.tab2 = QTableWidget(self)
        self.tab2.setColumnCount(1)
        self.tab2.setRowCount(5)
        self.tab2.setMaximumWidth(300)
        self.tab2.move(30, 265)
        self.tab2.setFixedSize(317, 130)
        self.tab2.verticalHeader().setDefaultSectionSize(20)
        self.tab2.horizontalHeader().setDefaultSectionSize(317)
        self.tab2.setHorizontalHeaderLabels(["Навание"])

        self.tab3 = QTableWidget(self)
        self.tab3.setColumnCount(1)
        self.tab3.setRowCount(5)
        self.tab3.setMaximumWidth(300)
        self.tab3.move(30, 455)
        self.tab3.setFixedSize(317, 130)
        self.tab3.verticalHeader().setDefaultSectionSize(20)
        self.tab3.horizontalHeader().setDefaultSectionSize(317)
        self.tab3.setHorizontalHeaderLabels(["Навание"])

        self.tab4 = QTableWidget(self)
        self.tab4.setColumnCount(1)
        self.tab4.setRowCount(5)
        self.tab4.setMaximumWidth(300)
        self.tab4.move(400, 75)
        self.tab4.setFixedSize(317, 130)
        self.tab4.verticalHeader().setDefaultSectionSize(20)
        self.tab4.horizontalHeader().setDefaultSectionSize(317)
        self.tab4.setHorizontalHeaderLabels(["Навание"])

        self.tab5 = QTableWidget(self)
        self.tab5.setColumnCount(1)
        self.tab5.setRowCount(5)
        self.tab5.setMaximumWidth(300)
        self.tab5.move(400, 265)
        self.tab5.setFixedSize(317, 130)
        self.tab5.verticalHeader().setDefaultSectionSize(20)
        self.tab5.horizontalHeader().setDefaultSectionSize(317)
        self.tab5.setHorizontalHeaderLabels(["Навание"])

        self.tab6 = QTableWidget(self)
        self.tab6.setColumnCount(1)
        self.tab6.setRowCount(5)
        self.tab6.setMaximumWidth(300)
        self.tab6.move(400, 455)
        self.tab6.setFixedSize(317, 130)
        self.tab6.verticalHeader().setDefaultSectionSize(20)
        self.tab6.horizontalHeader().setDefaultSectionSize(317)
        self.tab6.setHorizontalHeaderLabels(["Навание"])

        self.tab7 = QTableWidget(self)
        self.tab7.setColumnCount(1)
        self.tab7.setRowCount(5)
        self.tab7.setMaximumWidth(300)
        self.tab7.move(240, 645)
        self.tab7.setFixedSize(317, 130)
        self.tab7.verticalHeader().setDefaultSectionSize(20)
        self.tab7.horizontalHeader().setDefaultSectionSize(317)
        self.tab7.setHorizontalHeaderLabels(["Навание"])

        def run1(self, day_r, tab_name):
            self.con = sqlite3.connect('cinema_films.db')
            with self.con:
                cur = self.con.cursor()
                cur.execute(f"SELECT title FROM films WHERE day='{day_r}'")
                rows = cur.fetchall()
                k = 0
                for row in rows:
                    tab_name.setItem(k, 0, QTableWidgetItem(str(row)[2:-3]))
                    k = k + 1
            if self.con:
                self.con.close()

        run1(self, 'Monday', self.tab1)
        run1(self, 'Tuesday', self.tab2)
        run1(self, 'Wednesday', self.tab3)
        run1(self, 'Thursday', self.tab4)
        run1(self, 'Friday', self.tab5)
        run1(self, 'Saturday', self.tab6)
        run1(self, 'Sunday', self.tab7)

        def create_label(day, i):
            self.n_l = QLabel(day, self)
            if 0 <= i <= 2:
                self.n_l.move(70, 25 + i * 190)
            elif i == 6:
                self.n_l.move(340, 595)
            else:
                i -= 3
                self.n_l.move(410, 25 + i * 190)
            self.n_l.setStyleSheet('QLabel {color: red;}')
            self.n_l.setFont(QFont('Gothic', 20))

        create_label('𝐌𝐨𝐧𝐝𝐚𝐲', 0)
        create_label('𝐓𝐮𝐞𝐬𝐝𝐚𝐲', 1)
        create_label('𝐖𝐞𝐝𝐧𝐞𝐬𝐝𝐚𝐲', 2)
        create_label('𝐓𝐡𝐮𝐫𝐬𝐝𝐚𝐲', 3)
        create_label('𝐅𝐫𝐢𝐝𝐚𝐲', 4)
        create_label('𝐒𝐚𝐭𝐮𝐫𝐝𝐚𝐲', 5)
        create_label('𝐒𝐮𝐧𝐝𝐚𝐲', 6)

    def open_start_window(self):
        self.close()
        self.start_window = Start_window(self.png_name1)
        self.start_window.show()


class Settings(QWidget):
    def __init__(self, png_name='start_bg.png'):
        super().__init__()

        self.setWindowTitle("Настройки")
        self.setGeometry(0, 0, 831, 581)
        self.setFixedSize(831, 581)
        self.png_name1 = png_name

        self.lbl = QLabel(self)
        self.pix = QtGui.QPixmap(png_name)
        self.lbl.setPixmap(self.pix)
        self.lbl.move(0, 0)

        self.btn1 = QPushButton('<--', self)
        self.btn1.move(5, 5)
        self.btn1.resize(40, 30)
        self.btn1.clicked.connect(self.open_start_window)
        self.btn1.setStyleSheet('QPushButton {background-color: black; color: red;}')
        self.btn1.setFont(QFont('Gothic', 20))

        self.lbl2 = QLabel(self)
        self.lbl2.setGeometry(50, 50, 731, 500)
        self.lbl2.setStyleSheet('QLabel {background-color: white;}')

        self.btn2 = QPushButton('Выбрать первый фон', self)
        self.btn2.setGeometry(60, 50, 350, 20)
        self.btn2.clicked.connect(self.set_f1)

        self.btn3 = QPushButton('Выбрать второй фон', self)
        self.btn3.setGeometry(420, 50, 350, 20)
        self.btn3.clicked.connect(self.set_f2)

        self.btn4 = QPushButton('Выбрать третий фон', self)
        self.btn4.setGeometry(60, 300, 350, 20)
        self.btn4.clicked.connect(self.set_f3)

        self.btn5 = QPushButton('Выбрать четвёртый фон', self)
        self.btn5.setGeometry(420, 300, 350, 20)
        self.btn5.clicked.connect(self.set_f4)

        self.lbl3 = QLabel(self)
        self.lbl3.setGeometry(60, 80, 350, 210)
        self.pix1 = QtGui.QPixmap('start_bg.png')
        self.lbl3.setPixmap(self.pix1)

        self.lbl4 = QLabel(self)
        self.lbl4.setGeometry(420, 80, 350, 210)
        self.pix2 = QtGui.QPixmap('start_bg2.png')
        self.lbl4.setPixmap(self.pix2)

        self.lbl5 = QLabel(self)
        self.lbl5.setGeometry(60, 330, 350, 210)
        self.pix3 = QtGui.QPixmap('start_bg3.png')
        self.lbl5.setPixmap(self.pix3)

        self.lbl6 = QLabel(self)
        self.lbl6.setGeometry(420, 330, 350, 210)
        self.pix4 = QtGui.QPixmap('start_bg4.png')
        self.lbl6.setPixmap(self.pix4)

    def set_f1(self):
        png_name1 = 'start_bg.png'
        self.close()
        self.settings = Settings(png_name1)
        self.settings.show()

    def set_f2(self):
        png_name1 = 'start_bg2.png'
        self.close()
        self.settings = Settings(png_name1)
        self.settings.show()

    def set_f3(self):
        png_name1 = 'start_bg3.png'
        self.close()
        self.settings = Settings(png_name1)
        self.settings.show()

    def set_f4(self):
        png_name1 = 'start_bg4.png'
        self.close()
        self.settings = Settings(png_name1)
        self.settings.show()

    def open_start_window(self):
        self.close()
        self.start_window = Start_window(self.png_name1)
        self.start_window.show()


class First_error(QWidget):
    def __init__(self):
        super().__init__()
        self.setGeometry(990, 640, 300, 100)
        self.setFixedSize(300, 100)
        self.setWindowTitle('Error')
        self.l1 = QLabel('Все ячейки должны быть заполнены!', self)
        self.l1.move(53, 20)
        self.btn = QPushButton('ОК', self)
        self.btn.move(100, 70)
        self.btn.clicked.connect(self.run1)

    def run1(self):
        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    wnd = Start_window()
    wnd.show()
    sys.exit(app.exec_())
